/**
 * Modern Hyundai Mobis Chatbot Frontend
 * Enhanced UI/UX with smooth animations and better user experience
 */

class HyundaiMobisChatbot {
  constructor() {
    this.initializeElements();
    this.initializeState();
    this.attachEventListeners();
    this.initializeUI();
  }

  initializeElements() {
    // Main containers
    this.chatContainer = document.getElementById('chatMessages');
    this.flowContainer = document.getElementById('flowContainer');
    this.productCarousel = document.getElementById('productCarousel');
    this.loading = document.getElementById('loading');
    
    // Flow steps
    this.modelStep = document.getElementById('modelStep');
    this.typeStep = document.getElementById('typeStep');
    
    // Input elements
    this.userInput = document.getElementById('userInput');
    this.sendButton = document.getElementById('sendButton');
    this.inputValidation = document.getElementById('inputValidation');
    
    // Carousel elements
    this.carouselTrack = document.getElementById('carouselTrack');
    this.prevBtn = document.getElementById('prevBtn');
    this.nextBtn = document.getElementById('nextBtn');
    
    // Flow container now in input area
    this.flowContainer = document.querySelector('.flow-container');
  }

  initializeState() {
    this.flowState = {
      active: true,
      currentStep: 'model',
      selectedModel: null,
      selectedType: null
    };
    
    this.conversationHistory = [];
    this.products = [];
    this.currentCarouselIndex = 0;
    this.isLoading = false;
    
    // Search pattern tracking for better contextual suggestions
    this.searchPatterns = {
      modelsExplored: new Set(),
      accessoryTypes: new Set(),
      subtypesSearched: new Set(),
      recentSearches: []
    };
    
    // Debouncing for flow options to prevent double-clicks
    this.lastFlowOptionClick = 0;
    this.flowOptionDebounceTime = 300; // 300ms debounce
    
    // Spam detection
    this.spamDetection = {
      unrelatedQueries: 0,
      lastQueryTime: 0,
      TIME_WINDOW: 60000,
      MAX_UNRELATED: 3
    };
  }

  attachEventListeners() {
    // Input handlers
    this.userInput.addEventListener('keydown', (e) => this.handleKeyDown(e));
    this.userInput.addEventListener('input', () => this.handleInputChange());
    this.sendButton.addEventListener('click', () => this.handleSendMessage());
    
    // Flow option handlers with improved event delegation
    this.flowContainer.addEventListener('click', (e) => {
      // Find the closest flow-option element (handles clicks on span inside)
      const flowOption = e.target.closest('.flow-option');
      if (flowOption) {
        e.preventDefault();
        e.stopPropagation();
        this.handleFlowOption(flowOption);
      }
    });
    
    // Flow container is now in input area - event listener already set above
    
    // Carousel handlers
    this.prevBtn.addEventListener('click', () => this.navigateCarousel('prev'));
    this.nextBtn.addEventListener('click', () => this.navigateCarousel('next'));
    
    // Auto-resize textarea
    this.userInput.addEventListener('input', () => this.autoResizeTextarea());
  }

  initializeUI() {
    this.scrollToBottom();
    this.userInput.focus();
    this.updateCarouselControls();
  }

  // Input Handling
  handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.handleSendMessage();
    }
  }

  handleInputChange() {
    const wordCount = this.userInput.value.trim().split(/\s+/).length;
    const isValid = wordCount <= 100 && this.userInput.value.trim().length > 0;
    
    if (wordCount > 100) {
      this.showInputValidation();
    } else {
      this.hideInputValidation();
    }
    
    this.sendButton.disabled = !isValid || this.isLoading;
  }

  autoResizeTextarea() {
    this.userInput.style.height = 'auto';
    this.userInput.style.height = Math.min(this.userInput.scrollHeight, 120) + 'px';
  }

  showInputValidation() {
    this.inputValidation.classList.remove('hidden');
  }

  hideInputValidation() {
    this.inputValidation.classList.add('hidden');
  }

  // Message Handling
  async handleSendMessage() {
    const message = this.userInput.value.trim();
    if (!message || this.isLoading) return;

    // Check spam detection
    if (this.isSpamDetected()) {
      this.showSpamWarning();
      return;
    }

    this.addMessage('user', message);
    this.userInput.value = '';
    this.autoResizeTextarea();
    this.showLoading();

    try {
      await this.sendToLLM(message);
    } catch (error) {
      console.error('Error sending message:', error);
      this.addMessage('assistant', 'Sorry, I encountered an error. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  async sendToLLM(message) {
    const contextualMessage = this.buildContextualMessage(message);
    
      const response = await fetch('/api/llm-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
        user_input: contextualMessage,
          conversation_history: this.conversationHistory
        })
      });

      const data = await response.json();
    console.log('🔍 Raw LLM Response:', data);
      
      if (data.content && data.content[0] && data.content[0].text) {
          const responseData = JSON.parse(data.content[0].text);
      console.log('📊 Parsed Response Data:', responseData);
      
      this.handleLLMResponse(responseData, message);
    }
  }

  handleLLMResponse(responseData, originalMessage) {
    if (responseData.code === "1") {
      this.addFallbackMessage();
      this.updateSpamDetection(true);
    } else if (responseData.code === "0") {
          this.addMessage('assistant', responseData.message);
          
      console.log('🛍️ Products in response:', responseData.products);
      console.log('🎠 Show carousel flag:', responseData.show_carousel);
      
          if (responseData.products && responseData.products.length > 0 && responseData.show_carousel) {
        console.log('✅ Showing product carousel with', responseData.products.length, 'products');
            this.showProductCarousel(responseData.products);
      } else if (responseData.show_alternatives) {
        console.log('🔄 Showing alternative options for empty results');
        this.showAlternativeOptions();
      } else {
        console.log('❌ Not showing carousel - missing products or show_carousel flag');
      }
      
      this.updateSpamDetection(false);
          }
          
                // Update conversation history with search context and track patterns
      let contextualUserMessage = originalMessage;
      if (responseData.products && responseData.products.length > 0) {
        const { selectedModel, selectedType, selectedSubtype } = this.flowState;
        
        // Track search patterns for contextual suggestions
        if (selectedModel) this.searchPatterns.modelsExplored.add(selectedModel);
        if (selectedType) this.searchPatterns.accessoryTypes.add(selectedType);
        if (selectedSubtype) this.searchPatterns.subtypesSearched.add(selectedSubtype);
        
        // Keep recent searches for context
        const searchInfo = {
          model: selectedModel,
          query: originalMessage,
          timestamp: Date.now()
        };
        this.searchPatterns.recentSearches.unshift(searchInfo);
        if (this.searchPatterns.recentSearches.length > 5) {
          this.searchPatterns.recentSearches.pop();
        }
        
        const searchContext = [];
        if (selectedModel) searchContext.push(`searched ${selectedModel}`);
        if (selectedType) searchContext.push(`${selectedType} accessories`);
        if (selectedSubtype) searchContext.push(`specifically ${selectedSubtype}`);
        
        if (searchContext.length > 0) {
          contextualUserMessage = `${originalMessage} (user ${searchContext.join(' ')})`;
        }
      }
      
          this.conversationHistory.push(
        { role: 'user', content: contextualUserMessage },
        { role: 'assistant', content: responseData.message || 'I can help you with Hyundai Mobis accessories.' }
          );
  }

  buildContextualMessage(message) {
    const { selectedModel, selectedType, selectedSubtype } = this.flowState;
    
    let context = '';
    if (selectedModel) context += `Model: ${selectedModel}. `;
    if (selectedType) context += `Type: ${selectedType}. `;
    if (selectedSubtype) context += `Subtype: ${selectedSubtype}. `;
    
    // Add search patterns for contextual suggestions (especially for "thanks" responses)
    if (this.searchPatterns.recentSearches.length > 0) {
      context += `Previous searches: `;
      this.searchPatterns.recentSearches.forEach((search, index) => {
        if (index < 3) { // Only include last 3 searches
          context += `${search.model}`.trim();
          if (index < Math.min(2, this.searchPatterns.recentSearches.length - 1)) context += ', ';
        }
      });
      context += '. ';
    }
    
    return context ? `${context}User query: ${message}` : message;
  }

  // Flow Handling
  handleFlowOption(option) {
    // Debounce to prevent double-clicks
    const now = Date.now();
    if (now - this.lastFlowOptionClick < this.flowOptionDebounceTime) {
      console.log('🚫 Flow option click debounced');
      return;
    }
    this.lastFlowOptionClick = now;
    
    // Remove selection from siblings
    option.parentElement.querySelectorAll('.flow-option').forEach(opt => {
      opt.classList.remove('selected');
    });
    
    // Mark as selected with animation
    option.classList.add('selected');
    
    // Process the selection
    const step = this.flowState.currentStep;
    
    if (step === 'model') {
      this.flowState.selectedModel = option.dataset.model;
      this.proceedToTypeStep();
    } else if (step === 'type') {
      this.flowState.selectedType = option.dataset.type;
      // Execute search immediately after type selection
      this.executeRuleBasedSearch();
    }
  }

  proceedToTypeStep() {
    this.flowState.currentStep = 'type';
    this.animateStepTransition(this.modelStep, this.typeStep);
  }

  animateStepTransition(fromStep, toStep) {
    fromStep.style.opacity = '0.5';
    
    setTimeout(() => {
      fromStep.classList.add('hidden');
      toStep.classList.remove('hidden');
      toStep.style.opacity = '0';
      
      setTimeout(() => {
        toStep.style.opacity = '1';
        toStep.style.transition = 'opacity 0.3s ease';
      }, 50);
    }, 200);
  }

  async executeRuleBasedSearch() {
    const { selectedModel, selectedType, selectedSubtype } = this.flowState;
    
    let searchQuery = `Show me ${selectedType || 'all'} accessories for ${selectedModel}`;
    if (selectedSubtype) {
      searchQuery = `Show me ${selectedSubtype} for ${selectedModel}`;
    }
    
    this.addMessage('user', searchQuery);
    this.showLoading();
    
    try {
      await this.sendToLLM(searchQuery);
    } catch (error) {
      console.error('Error in rule-based search:', error);
      this.addMessage('assistant', 'Sorry, I encountered an error while searching. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  // Flow Management (previously handled by quick actions)

  restartFlow() {
    // Reset flow state
    this.flowState = {
      active: true,
      currentStep: 'model',
      selectedModel: null,
      selectedType: null
    };
    
    // Reset UI
    this.hideProductCarousel();
    this.modelStep.classList.remove('hidden');
    this.typeStep.classList.add('hidden');
    
    // Clear selections
    this.flowContainer.querySelectorAll('.flow-option').forEach(opt => {
      opt.classList.remove('selected');
    });
    
    this.addMessage('assistant', 'Let\'s start fresh! Please select your Hyundai model to find the perfect accessories.');
  }

  // UI Helpers
  addMessage(sender, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = sender === 'user' ? 'U' : 'AI';
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    messageContent.innerHTML = content.replace(/\n/g, '<br>');
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(messageContent);
    
    this.chatContainer.appendChild(messageDiv);
    this.scrollToBottom();
  }

  addFallbackMessage() {
    const fallbackDiv = document.createElement('div');
    fallbackDiv.className = 'fallback-message';
    fallbackDiv.innerHTML = `
      <strong>I can only help with Hyundai Mobis accessories and parts.</strong><br>
      Please ask about car accessories, parts, or use the options above to browse our catalog.
    `;
    this.chatContainer.appendChild(fallbackDiv);
    this.scrollToBottom();
  }

  showSpamWarning() {
    const warningDiv = document.createElement('div');
    warningDiv.className = 'fallback-message';
    warningDiv.innerHTML = `
      <strong>Warning: Please focus on Hyundai accessories.</strong><br>
      I noticed you've asked several unrelated questions. Let me help you find the right car parts and accessories!
    `;
    this.chatContainer.appendChild(warningDiv);
    this.scrollToBottom();
  }

  showLoading() {
    this.isLoading = true;
    this.loading.classList.remove('hidden');
    this.sendButton.disabled = true;
    this.scrollToBottom();
  }

  hideLoading() {
    this.isLoading = false;
    this.loading.classList.add('hidden');
    this.sendButton.disabled = false;
  }

  scrollToBottom() {
    setTimeout(() => {
      this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
    }, 100);
  }

  // Product Carousel
  showProductCarousel(products) {
    console.log('🎠 showProductCarousel called with:', products);
    this.products = products;
    this.currentCarouselIndex = 0;
    
    this.renderProductCards();
    this.productCarousel.classList.remove('hidden');
    this.productCarousel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    this.updateCarouselControls();
    console.log('✅ Product carousel should now be visible');
  }

  hideProductCarousel() {
    this.productCarousel.classList.add('hidden');
    this.products = [];
    this.currentCarouselIndex = 0;
  }

  showAlternativeOptions() {
    const { selectedModel, selectedType, selectedSubtype } = this.flowState;
    
    // Create alternatives message
    const alternativesDiv = document.createElement('div');
    alternativesDiv.className = 'alternatives-message';
    alternativesDiv.innerHTML = `
      <div class="alternatives-header">
        <strong>Try these alternatives:</strong>
      </div>
      <div class="alternatives-actions">
        ${selectedModel ? `<button class="alternative-btn" data-action="searchAll" data-model="${selectedModel}">Browse All ${selectedModel} Accessories</button>` : ''}
        ${selectedType ? `<button class="alternative-btn" data-action="searchDifferentType" data-model="${selectedModel}" data-type="${selectedType}">Try Different ${selectedType} Items</button>` : ''}
        <button class="alternative-btn" data-action="searchPopular">View Popular Accessories</button>
        <button class="alternative-btn" data-action="restart">Choose Different Car Model</button>
      </div>
    `;
    
    // Add event listeners to the buttons
    const buttons = alternativesDiv.querySelectorAll('.alternative-btn');
    buttons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.handleAlternativeAction(button);
      });
    });
    
    this.chatContainer.appendChild(alternativesDiv);
    this.scrollToBottom();
  }

  handleAlternativeAction(button) {
    const action = button.dataset.action;
    const model = button.dataset.model;
    
    switch (action) {
      case 'searchAll':
        this.searchAllAccessories(model);
        break;
      case 'searchDifferentType':
        this.searchByDifferentType(model);
        break;
      case 'searchPopular':
        this.searchPopularAccessories();
        break;
      case 'restart':
        this.restartFlow();
        break;
    }
  }

  async searchAllAccessories(model) {
    const searchQuery = `Show me all accessories for ${model}`;
    this.addMessage('user', searchQuery);
    this.showLoading();
    
    try {
      await this.sendToLLM(searchQuery);
    } catch (error) {
      console.error('Error searching all accessories:', error);
      this.addMessage('assistant', 'Sorry, I encountered an error while searching. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  async searchByDifferentType(model) {
    const types = ['Interiors', 'Exteriors', 'Electronics', 'Common'];
    const randomType = types[Math.floor(Math.random() * types.length)];
    
    const searchQuery = `Show me ${randomType} accessories for ${model}`;
    this.addMessage('user', searchQuery);
    this.showLoading();
    
    try {
      await this.sendToLLM(searchQuery);
    } catch (error) {
      console.error('Error searching by different type:', error);
      this.addMessage('assistant', 'Sorry, I encountered an error while searching. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  async searchPopularAccessories() {
    // Use current model if available, otherwise default to popular Creta
    const { selectedModel } = this.flowState;
    const model = selectedModel || 'Creta';
    
    const searchQuery = `Show me popular accessories for ${model}`;
    this.addMessage('user', searchQuery);
    this.showLoading();
    
    try {
      await this.sendToLLM(searchQuery);
    } catch (error) {
      console.error('Error searching popular accessories:', error);
      this.addMessage('assistant', 'Sorry, I encountered an error while searching. Please try again.');
    } finally {
      this.hideLoading();
    }
  }

  renderProductCards() {
    console.log('🎨 renderProductCards called with', this.products.length, 'products');
    this.carouselTrack.innerHTML = '';
    
    this.products.forEach((product, index) => {
      console.log(`🛍️ Rendering product ${index + 1}:`, product);
      const card = document.createElement('a');
      card.className = 'product-card';
      card.href = `https://hyundai.com/parts/${product.url || product.accessoryCode}`;
      card.target = '_blank';
      
      // Create a fixed placeholder for products without images
      const placeholderImage = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDI4MCAyMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIyODAiIGhlaWdodD0iMjAwIiBmaWxsPSIjRjJGNEY4Ii8+CjxwYXRoIGQ9Ik0xMTAgMTAwSDEwMFY5MEgxMTBWMTAwWk0xMTAgMTEwSDEwMFYxMDBIMTEwVjExMFpNMTIwIDEwMEgxMTBWOTBIMTIwVjEwMFpNMTIwIDExMEgxMTBWMTAwSDEyMFYxMTBaTTEzMCAxMDBIMTIwVjkwSDEzMFYxMDBaTTEzMCAxMTBIMTIwVjEwMEgxMzBWMTEwWk0xNDAgMTAwSDEzMFY5MEgxNDBWMTAwWk0xNDAgMTEwSDEzMFYxMDBIMTQwVjExMFpNMTUwIDEwMEgxNDBWOTBIMTUwVjEwMFpNMTUwIDExMEgxNDBWMTAwSDE1MFYxMTBaTTE2MCA5MEgxNTBWODBIMTYwVjkwWk0xNjAgMTAwSDE1MFY5MEgxNjBWMTAwWk0xNjAgMTEwSDE1MFYxMDBIMTYwVjExMFpNMTcwIDkwSDE2MFY4MEgxNzBWOTBaTTE3MCA4MEgxNjBWNzBIMTcwVjgwWk0xODAgODBIMTcwVjcwSDE4MFY4MFoiIGZpbGw9IiM2QjcyODAiLz4KPHRleHQgeD0iMTQwIiB5PSIxMzAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiM2QjcyODAiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZm9udC13ZWlnaHQ9IjUwMCI+UHJvZHVjdCBJbWFnZTwvdGV4dD4KPC9zdmc+';
      
      const imageUrl = product.image || placeholderImage;
      
      card.innerHTML = `
        <img src="${imageUrl}" 
             alt="${product.accessoryName || product.partName}" 
             class="product-image"
             onerror="this.src='${placeholderImage}'">
        <div class="product-info">
          <div class="product-title">${product.accessoryName || product.partName}</div>
          <div class="product-price">₹${product.mrp || product.price}</div>
          <div class="product-description">${this.stripHtml(product.body || product.description || 'No description available')}</div>
          <button class="product-cta" onclick="event.preventDefault(); window.open('${card.href}', '_blank')">
            View Details
          </button>
        </div>
      `;
      
      this.carouselTrack.appendChild(card);
    });
  }

  navigateCarousel(direction) {
    const totalProducts = this.products.length;
    const visibleProducts = Math.floor(this.carouselTrack.offsetWidth / 300); // Approximate card width
    
    if (direction === 'prev' && this.currentCarouselIndex > 0) {
      this.currentCarouselIndex--;
    } else if (direction === 'next' && this.currentCarouselIndex < totalProducts - visibleProducts) {
      this.currentCarouselIndex++;
    }
    
    this.updateCarouselControls();
    }

  updateCarouselControls() {
    const totalProducts = this.products.length;
    const visibleProducts = Math.floor(this.carouselTrack.offsetWidth / 300);
    
    this.prevBtn.disabled = this.currentCarouselIndex === 0;
    this.nextBtn.disabled = this.currentCarouselIndex >= totalProducts - visibleProducts || totalProducts <= visibleProducts;
  }

  // Spam Detection
  isSpamDetected() {
    const now = Date.now();
    const timeSinceLastQuery = now - this.spamDetection.lastQueryTime;
    
    if (timeSinceLastQuery > this.spamDetection.TIME_WINDOW) {
      this.spamDetection.unrelatedQueries = 0;
    }
    
    return this.spamDetection.unrelatedQueries >= this.spamDetection.MAX_UNRELATED;
  }

  updateSpamDetection(isUnrelated) {
    const now = Date.now();
    
    if (isUnrelated) {
      if (now - this.spamDetection.lastQueryTime < this.spamDetection.TIME_WINDOW) {
        this.spamDetection.unrelatedQueries++;
      } else {
        this.spamDetection.unrelatedQueries = 1;
      }
    } else {
      this.spamDetection.unrelatedQueries = 0;
  }

    this.spamDetection.lastQueryTime = now;
  }

  // Utility Functions
  stripHtml(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  }
}

// Initialize the chatbot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.chatbot = new HyundaiMobisChatbot();
}); 