# 🚗 Hyundai Mobis Accessories Chatbot

A sophisticated chatbot system for Hyundai Mobis accessories with **rule-based + AI hybrid flow**, featuring Anthropic Claude AI integration and comprehensive product discovery.

## 🏗️ System Architecture

The system consists of three main components:

1. **Server** (`server-only.js`) - Express server with MCP tools and API endpoints
2. **LLM Service** (`llm-service.js`) - Anthropic Claude AI integration with guardrails
3. **Frontend** (`frontend-client.js`) - Rule-based + AI hybrid chat interface

## 🧠 Core Intelligence Flow (Rule-based + AI Hybrid)

### 🔹 Rule-Based Flow (Default Mode):
- **Welcome Message** → **Car Model Selection** → **Year Selection** → **Type Selection** → **Subtype Selection**
- Direct API calls via MCP tools: `searchAccessories`, `findbyType`, `findbySubtype`
- Instant product carousel display without LLM processing

### 🔹 Natural Text Input (User Interrupts Flow):
- Example: *"Show me white seat covers for Creta 2018"*
- Sends collected metadata (Car model, Type, Subtype) + user prompt to LLM
- LLM uses only MCP tools (`searchAccessories`, `findbySubtype`, etc.)
- **Does NOT pass API response JSON to LLM** - direct frontend display

### 🔹 Freeform Chat (Complete Text Chat):
- Forward to LLM with session metadata
- LLM invokes proper MCP tool based on query
- Backend processes tool call and displays products in carousel

## 🚨 Edge Cases & Guardrails

### ❌ Unrelated Queries:
- **Weather, politics, general topics** → LLM responds with `{"code": "1"}`
- Mapped to fallback: *"Please ask about Hyundai Mobis accessories or parts."*

### 🛡️ LLM Guardrails:
- **Must not answer directly** - always invoke MCP tools
- **JSON-only responses**: `{"code": "0", "message": "...", "tool_used": "..."}`
- **100-word input limit** with client-side validation
- **Spam detection** for repeated unrelated queries (3 strikes in 60 seconds)

## 🔧 Available MCP Tools

| Tool | Description |
|------|-------------|
| `searchAccessories` | Search all accessories for model/year |
| `findbyType` | Find by type (Interior, Exterior, Electronics, Common) |
| `findbySubtype` | Find by specific subtype (Seat Cover, Floor Mat, etc.) |
| `findbyPriceRange` | Find accessories within price range |
| `searchParts` | Search car parts (not accessories) |

## 🎨 UI/UX Features

### 🎯 Hyundai Brand Compliance:
- **Colors**: Primary Blue (#1A73E8), Soft White (#F2F4F8), Soft Yellow (#FFD369)
- **Font**: Poppins throughout
- **Design**: Flat design, no gradients
- **Position**: Bottom-right corner embedded chatbot

### 📱 Product Carousel:
- **Horizontal scrollable** card layout
- **Pagination** for >4 products
- **Clickable cards** → redirect to `https://hyundai.com/parts/{urlText}`
- **Product details**: Title, Image, Price, Description, CTA Button

### ⚡ Interactive Features:
- **Quick Actions**: Browse All, Popular, Help, Start Over
- **Flow Restart**: Reset to model selection
- **Input Validation**: Real-time word count, 100-word limit
- **Connection Status**: Live API connectivity indicator

## 🚀 Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Set up environment variables:**
   Create a `.env` file in the project root:
   ```
   ANTHROPIC_API_KEY=your_anthropic_api_key_here
   ```

3. **Start the application:**
   ```bash
   npm start
   ```

4. **Open your browser:**
   - Main interface: `http://localhost:3000`

## 🔌 API Endpoints

### Core Endpoints:
- `POST /api/llm-query` - Process natural language queries
- `POST /api/mcp-call` - Direct MCP tool calls
- `GET /api/health` - Health check

### Metadata Endpoints:
- `GET /api/accessory-types` - Get all accessory types
- `GET /api/accessory-subtypes` - Get all accessory subtypes  
- `GET /api/parts-types` - Get all parts types

## 📊 Hyundai API Integration

### Accessories API:
```
https://api.hyundaimobisin.com/service/accessories/getByModelIdYear?modelId=XX&year=2018
```

### Parts API:
```
https://api.hyundaimobisin.com/service/parts/getByModelIdAndYear?modelId=1&year=2018
```

### Model ID Mappings:
```javascript
'creta': 29, 'alcazar': 34, 'i20': 27, 'venue': 20, 'exter': 26, 
'verna': 23, 'aura': 24, 'kona': 33, 'tucson': 30, 'ioniq': 32
```

## 💬 Example Interactions

### Rule-Based Flow:
```
Bot: "Select your Hyundai model:"
User: [Clicks "Creta"]
Bot: "Select your model year:"
User: [Clicks "2018"]
Bot: "What type of accessories?"
User: [Clicks "Interior"]
Bot: "Choose a specific category:"
User: [Clicks "Seat Cover"]
→ Shows product carousel with seat covers
```

### Natural Language:
```
User: "Show me seat covers for Creta 2018"
Bot: "I'll find seat covers for your 2018 Creta!" 
→ Uses findbySubtype tool → Shows carousel
```

### Fallback Handling:
```
User: "What's the weather today?"
Bot: "🚗 I can only help with Hyundai Mobis accessories and parts."
```

## 🛠️ Development

For development with auto-restart:
```bash
npm run dev
```

## 📋 Requirements

- Node.js 18+
- Anthropic API key
- Internet connection for Hyundai APIs

## 🔒 Security Features

- **API key** stored in environment variables
- **Domain-restricted** AI responses (automotive only)
- **Input validation** and sanitization
- **Spam detection** and rate limiting
- **CORS protection**

## 📄 License

MIT License - see LICENSE file for details. 