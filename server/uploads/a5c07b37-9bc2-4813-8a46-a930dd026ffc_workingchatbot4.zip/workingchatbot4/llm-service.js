/**
 * Anthropic Claude LLM Service for Hyundai Mobis Accessories
 * This service handles real LLM integration with custom MCP tools
 */

import Anthropic from '@anthropic-ai/sdk';
import dotenv from 'dotenv';
import axios from 'axios';

dotenv.config();

class HyundaiMobisLLMService {
  constructor() {
    this.anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
    
    this.model = "claude-sonnet-4-20250514";
    // this.model = "claude-3-5-haiku-20241022";
    this.maxTokens = 8192;
    this.temperature = 1;
    
    this.systemPrompt = `You are a Hyundai Mobis chatbot assistant. You MUST follow these strict rules:

RESPONSE CATEGORIES:
1. CONVERSATIONAL QUERIES: Handle directly without tools
   - Greetings: "Hi", "Hello", "Good morning"
   - Thanks: "Appreciate it" - ANALYZE CONVERSATION HISTORY for contextual suggestions
   - Context questions: "What car did we discuss?", "What were we talking about?"
   - General Mobis questions: "What is Hyundai Mobis?", "Tell me about your company"
   - Clarifications: "Can you help me?", "What can you do?"

2. PRODUCT SEARCH QUERIES: Use MCP tools
   - Specific accessory requests: "Show me seat covers", "Find floor mats"
   - Type-based searches: "Interior accessories", "Exterior parts"
   - Price-based searches: "Accessories under 5000", "Parts between 1000-3000"
   - Model-specific searches: "Creta accessories", "Alcazar parts"

3. UNRELATED QUERIES: Reject with code 1
   - Weather, politics, general knowledge, non-automotive topics

AVAILABLE MCP TOOLS (use for product searches ONLY):
- searchAccessories(model, year): Search all accessories for a model/year
- findbyType(model, year, type): Find accessories by type (Interiors, Exteriors, Electronics, Common)
- findbySubtype(model, year, subtype): Find accessories by specific subtype
- findbyPriceRange(model, year, minPrice, maxPrice): Find accessories within price range
- searchParts(model, year): Search car parts for a model/year

CRITICAL: When calling ANY tool, ALWAYS use year=2018. Do not use 2023, 2024, or any other year.

RESPONSE FORMATS:
For conversational queries: {"code": "0", "message": "direct_response"}
For product searches: {"code": "0", "message": "response", "tool_used": "tool_name", "products": [tool_result], "show_carousel": true}
For unrelated queries: {"code": "1"}

CONTEXTUAL MEMORY RULES FOR "THANKS" RESPONSES:
- ANALYZE conversation history to identify: car models discussed, accessories searched, types explored
- PROVIDE personalized suggestions based on previous searches
- MAKE suggestions subtle and helpful, not pushy
- REFERENCE specific items user showed interest in

EXAMPLES:
User: "Thanks for helping me!" (after searching Creta speakers)
Response: {"code": "0", "message": "You're welcome! Since you were interested in Creta speakers, would you like to explore other interior accessories like seat covers or floor mats for your Creta?"}

User: "Thanks!" (after checking i20 accessories, then Creta speakers)
Response: {"code": "0", "message": "Happy to help! I noticed you looked at both i20 accessories and Creta speakers. Would you like to check some audio accessories for your i20 before you go?"}

User: "Thank you" (after browsing multiple exterior items)
Response: {"code": "0", "message": "You're welcome! You seemed interested in exterior accessories - would you like to see some interior options to complete your car's makeover?"}

User: "What car did we talk about before?"
Response: {"code": "0", "message": "We were discussing your Hyundai Creta. Would you like to continue exploring accessories for it?"}

User: "What is Hyundai Mobis?"
Response: {"code": "0", "message": "Hyundai Mobis is a leading automotive parts supplier that provides high-quality accessories and parts for Hyundai vehicles. I can help you find the perfect accessories for your car!"}

User: "Show me seat covers for Creta"
Response: {"code": "0", "message": "I'll find seat covers for your Creta!", "tool_used": "findbySubtype", "products": [actual_tool_result], "show_carousel": true}

User: "Show me popular accessories"
Response: {"code": "0", "message": "Here are some popular accessories across different models!", "tool_used": "searchAccessories", "products": [actual_tool_result], "show_carousel": true}

User: "What's the weather today?"
Response: {"code": "1"}

IMPORTANT: 
- Keep conversational responses brief and friendly
- Always steer conversation back to Mobis products
- ANALYZE conversation history thoroughly for contextual suggestions
- For "thanks" responses, identify patterns: models discussed, accessories searched, types explored
- Make suggestions based on complementary products or different models mentioned
- Use tools only for actual product searches
- For price ranges, use findbyPriceRange tool
- For specific types, use findbyType tool
- For specific subtypes, use findbySubtype tool
- For general searches, use searchAccessories tool
- For parts (not accessories), use searchParts tool

CONTEXTUAL SUGGESTION PATTERNS:
- If user searched specific accessory → suggest complementary accessories for same model
- If user explored multiple models → suggest accessories for previously mentioned but less explored model
- If user focused on one type (interior/exterior) → subtly suggest exploring the other type
- If user searched specific subtype → suggest related subtypes or broader category

NEVER provide direct product information - always use tools and let the frontend display results.`;

    this.tools = [
      {
        name: "searchAccessories",
        description: "Search all accessories for a specific Hyundai model and year",
        input_schema: {
          type: "object",
          properties: {
            model: {
              type: "string",
              description: "Hyundai model name (e.g., creta, i20, alcazar, venue, etc.)",
              enum: [
                "creta", "alcazar", "creta n line", "i20", "exter", "verna",
                "i10 nios", "aura", "venue nline", "venue", "kona", "tucson", "ioniq"
              ]
            },
            year: {
              type: "integer",
              description: "Model year - ALWAYS use 2018",
              minimum: 2015,
              maximum: 2025,
              default: 2018
            }
          },
          required: ["model", "year"]
        }
      },
      {
        name: "findbyType",
        description: "Find accessories by type/category (Interior, Exteriors, Electronics, Common)",
        input_schema: {
          type: "object",
          properties: {
            model: {
              type: "string",
              description: "Hyundai model name",
              enum: [
                "creta", "alcazar", "creta n line", "i20", "exter", "verna",
                "i10 nios", "aura", "venue nline", "venue", "kona", "tucson", "ioniq"
              ]
            },
            year: {
              type: "integer",
              description: "Model year",
              minimum: 2015,
              maximum: 2025
            },
            type: {
              type: "string",
              description: "Accessory type (Interiors, Exteriors, Electronics, Common)",
              enum: ["Interiors", "Exteriors", "Electronics", "Common"]
            }
          },
          required: ["model", "year", "type"]
        }
      },
      {
        name: "findbySubtype",
        description: "Find accessories by specific subtype category",
        input_schema: {
          type: "object",
          properties: {
            model: {
              type: "string",
              description: "Hyundai model name",
              enum: [
                "creta", "alcazar", "creta n line", "i20", "exter", "verna",
                "i10 nios", "aura", "venue nline", "venue", "kona", "tucson", "ioniq"
              ]
            },
            year: {
              type: "integer",
              description: "Model year",
              minimum: 2015,
              maximum: 2025
            },
            subtype: {
              type: "string",
              description: "Specific subtype like 'Seat Cover', 'Floor Mat', 'Alloy Wheel', etc."
            }
          },
          required: ["model", "year", "subtype"]
        }
      },
      {
        name: "findbyPriceRange",
        description: "Find accessories within a specific price range",
        input_schema: {
          type: "object",
          properties: {
            model: {
              type: "string",
              description: "Hyundai model name",
              enum: [
                "creta", "alcazar", "creta n line", "i20", "exter", "verna",
                "i10 nios", "aura", "venue nline", "venue", "kona", "tucson", "ioniq"
              ]
            },
            year: {
              type: "integer",
              description: "Model year",
              minimum: 2015,
              maximum: 2025
            },
            minPrice: {
              type: "number",
              description: "Minimum price in rupees"
            },
            maxPrice: {
              type: "number",
              description: "Maximum price in rupees"
            }
          },
          required: ["model", "year", "minPrice", "maxPrice"]
        }
      },
      {
        name: "searchParts",
        description: "Search car parts (not accessories) for a specific model and year",
        input_schema: {
          type: "object",
          properties: {
            model: {
              type: "string",
              description: "Hyundai model name",
              enum: [
                "creta", "alcazar", "creta n line", "i20", "exter", "verna",
                "i10 nios", "aura", "venue nline", "venue", "kona", "tucson", "ioniq"
              ]
            },
            year: {
              type: "integer",
              description: "Model year",
              minimum: 2015,
              maximum: 2025
            }
          },
          required: ["model", "year"]
        }
      }
    ];

    // Model mappings for API calls
    this.MODEL_MAPPINGS = {
        'creta ev': 35,
        'alcazar': 34,
        'creta n line': 31,
        'creta': 29,
        'i20': 27,
        'exter': 26,
        'verna': 23,
        'i10 nios': 25,
        'aura': 24,
        'venue nline': 22,
        'venue': 20,
        'kona': 33,
        'tucson': 30,
        'ioniq': 32,
      };

    // Spam detection
    this.userQueryHistory = new Map();
    this.SPAM_THRESHOLD = 3;
    this.SPAM_TIME_WINDOW = 60000; // 1 minute
  }

  /**
   * Check if user is spamming with unrelated queries
   */
  detectSpam(userId, query) {
    const now = Date.now();
    const userHistory = this.userQueryHistory.get(userId) || [];
    
    // Clean old entries
    const recentHistory = userHistory.filter(entry => now - entry.timestamp < this.SPAM_TIME_WINDOW);
    
    // Count unrelated queries
    const unrelatedCount = recentHistory.filter(entry => entry.isUnrelated).length;
    
    if (unrelatedCount >= this.SPAM_THRESHOLD) {
      return true;
    }
    
    return false;
  }

  /**
   * Update user query history
   */
  updateQueryHistory(userId, query, isUnrelated) {
    const now = Date.now();
    const userHistory = this.userQueryHistory.get(userId) || [];
    
    userHistory.push({
      query,
      timestamp: now,
      isUnrelated
    });
    
    // Keep only recent entries
    const recentHistory = userHistory.filter(entry => now - entry.timestamp < this.SPAM_TIME_WINDOW);
    this.userQueryHistory.set(userId, recentHistory);
  }

  /**
   * Validate input length (max 100 words)
   */
  validateInputLength(input) {
    const words = input.trim().split(/\s+/).length;
    return words <= 100;
  }

  /**
   * Process user query with Claude LLM
   */
  async processUserQuery(userInput, conversationHistory = [], userId = 'anonymous') {
    try {
      // Validate input length
      if (!this.validateInputLength(userInput)) {
        return {
          type: 'error',
          content: JSON.stringify({
            code: "1",
            message: "Please keep your message under 100 words for better assistance."
          })
        };
      }

      // Check for spam
      if (this.detectSpam(userId, userInput)) {
        return {
          type: 'error',
          content: JSON.stringify({
            code: "1",
            message: "Please ask about Hyundai Mobis accessories or parts."
          })
        };
      }

      console.log('🤖 Processing query with Claude LLM:', userInput);

      const messages = [
        ...conversationHistory,
        {
          role: "user",
          content: userInput
        }
      ];

      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: this.maxTokens,
        temperature: this.temperature,
        system: this.systemPrompt,
        messages: messages,
        tools: this.tools
      });

      console.log('🎯 Claude response received');

      // Handle tool calls
      if (response.content.some(content => content.type === 'tool_use')) {
        const result = await this.handleToolCalls(response, messages);
        
        // Update query history - tool calls are valid
        this.updateQueryHistory(userId, userInput, false);
        
        return result;
      }

      // Handle text response
      const textContent = response.content.find(content => content.type === 'text');
      const responseText = textContent?.text || '{"code": "1"}';
      
      // Try to parse JSON response
      try {
        const parsedResponse = JSON.parse(responseText);
        
        // Update query history based on response code
        this.updateQueryHistory(userId, userInput, parsedResponse.code === "1");
        
        return {
          type: 'structured',
          content: responseText,
          usage: response.usage
        };
      } catch (parseError) {
        // Invalid JSON, treat as unrelated
        this.updateQueryHistory(userId, userInput, true);
        
        return {
          type: 'structured',
          content: '{"code": "1"}',
          usage: response.usage
        };
      }

    } catch (error) {
      console.error('❌ Error calling Claude API:', error);
      
      // Check for connectivity issues
      const isConnectivityError = 
        error.message?.includes('ENOTFOUND') ||
        error.message?.includes('Connection error') ||
        error.message?.includes('fetch failed') ||
        error.message?.includes('getaddrinfo') ||
        error.cause?.code === 'ENOTFOUND' ||
        error.cause?.syscall === 'getaddrinfo';
      
      if (isConnectivityError) {
        return {
          type: 'error',
          content: JSON.stringify({
            code: "0",
            message: "🌐 I'm having trouble connecting to the AI service. Please check your internet connection and try again."
          }),
          error: error.message
        };
      }
      
      // For other API errors
      return {
        type: 'error',
        content: JSON.stringify({
          code: "0",
          message: "🤖 I'm experiencing technical difficulties with the AI service. Please try again in a moment."
        }),
        error: error.message
      };
    }
  }

  /**
   * Handle tool calls from Claude
   */
  async handleToolCalls(response, messages) {
    const toolResults = [];
    
    for (const content of response.content) {
      if (content.type === 'tool_use') {
        console.log(`🔧 Executing tool: ${content.name} with input:`, content.input);
        
        try {
          const result = await this.executeTool(content.name, content.input);
          toolResults.push({
            tool_use_id: content.id,
            type: "tool_result",
            content: JSON.stringify(result)
          });
        } catch (error) {
          console.error(`❌ Tool execution failed: ${content.name}`, error);
          toolResults.push({
            tool_use_id: content.id,
            type: "tool_result",
            content: JSON.stringify({
              error: `Failed to execute ${content.name}: ${error.message}`
            })
          });
        }
      }
    }

    // Return tool results directly to frontend for display
    console.log('🔧 Tool results:', toolResults);
    const products = toolResults.length > 0 ? JSON.parse(toolResults[0].content) : [];
    console.log('🛍️ Products to return:', products);
    
    // Handle empty results
    if (!products || products.length === 0) {
      return {
        type: 'tool_response',
        content: JSON.stringify({
          code: "0",
          message: "🔍 Sorry, no products found for your search. Let me suggest some alternatives:",
          products: [],
          show_carousel: false,
          show_alternatives: true
        }),
        tools_used: response.content.filter(c => c.type === 'tool_use').map(c => c.name),
        usage: response.usage
      };
    }
    
    return {
      type: 'tool_response',
      content: JSON.stringify({
        code: "0",
        message: "I found some great options for you!",
        products: products,
        show_carousel: true
      }),
      tools_used: response.content.filter(c => c.type === 'tool_use').map(c => c.name),
      usage: response.usage
    };
  }

  /**
   * Execute specific tools
   */
  async executeTool(toolName, input) {
    switch (toolName) {
      case 'searchAccessories':
        return await this.searchAccessories(input.model, input.year);
      
      case 'findbyType':
        return await this.findbyType(input.model, input.year, input.type);
      
      case 'findbySubtype':
        return await this.findbySubtype(input.model, input.year, input.subtype);
      
      case 'findbyPriceRange':
        return await this.findbyPriceRange(input.model, input.year, input.minPrice, input.maxPrice);
      
      case 'searchParts':
        return await this.searchParts(input.model, input.year);
      
      default:
        throw new Error(`Unknown tool: ${toolName}`);
    }
  }

  /**
   * Search all accessories for a specific model and year
   */
  async searchAccessories(model, year = 2018) {
    const modelId = this.MODEL_MAPPINGS[model.toLowerCase()];
    console.log(`🔍 searchAccessories: model=${model}, year=${year}, modelId=${modelId}`);
    
    if (!modelId) {
      throw new Error(`Model "${model}" not found in our database`);
    }

    try {
      const apiUrl = `https://api.hyundaimobisin.com/service/accessories/getByModelIdYear?modelId=${modelId}&year=${year}`;
      console.log(`🌐 API call: ${apiUrl}`);
      
      const response = await axios.get(apiUrl);
      console.log(`📡 API response status: ${response.status}`);
      console.log(`📊 API response data length: ${response.data ? response.data.length : 'null'}`);
      
      if (!response.data || !Array.isArray(response.data)) {
        console.log('❌ API returned invalid data format');
        return [];
      }
      
      const mappedData = response.data.map(item => ({
        id: item.id,
        accessoryName: item.accessoryName,
        accessoryCode: item.accessoryCode,
        body: item.body || 'No description available',
        typeId: item.typeId,
          type: item.type || 'General',
        subTypeId: item.subTypeId,
          subType: item.subType || 'Accessories',
        mrp: item.mrp,
        url: item.url,
        title: item.title,
          image: item.image ? `https://api.hyundaimobisin.com/service/asset/accessory/${item.image}` : null
      }));
      
      // Log unique types and subtypes to understand the data structure
      const uniqueTypes = [...new Set(response.data.map(item => item.type))];
      const uniqueSubTypes = [...new Set(response.data.map(item => item.subType))];
      console.log(`📊 Unique types in API response:`, uniqueTypes);
      console.log(`📊 Unique subtypes in API response:`, uniqueSubTypes);
      
      console.log(`✅ Mapped ${mappedData.length} accessories`);
      return mappedData;
    } catch (error) {
      console.error('❌ Error fetching accessories:', error);
      throw new Error(`Failed to fetch accessories: ${error.message}`);
    }
  }

  /**
   * Find accessories by type (Interior, Exterior, Electronics, Common)
   */
  async findbyType(model, year = 2018, type) {
    console.log(`🔍 findbyType called with: model=${model}, year=${year}, type=${type}`);
    const accessories = await this.searchAccessories(model, year);
    console.log(`📦 Found ${accessories.length} total accessories`);
    const filtered = accessories.filter(item => 
      item.type && item.type.toLowerCase() === type.toLowerCase()
    );
    console.log(`✅ Filtered to ${filtered.length} accessories of type ${type}`);
    return filtered;
  }

  /**
   * Find accessories by specific subtype
   */
  async findbySubtype(model, year = 2018, subtype) {
    const accessories = await this.searchAccessories(model, year);
    const searchTerm = subtype.toLowerCase();
    
    return accessories.filter(item => {
      // Search in subType field (original behavior)
      const subTypeMatch = item.subType && item.subType.toLowerCase().includes(searchTerm);
      
      // Search in product name
      const nameMatch = item.accessoryName && item.accessoryName.toLowerCase().includes(searchTerm);
      
      // Search in product description/body
      const bodyMatch = item.body && item.body.toLowerCase().includes(searchTerm);
      
      // Search in product title
      const titleMatch = item.title && item.title.toLowerCase().includes(searchTerm);
      
      return subTypeMatch || nameMatch || bodyMatch || titleMatch;
    });
  }

  /**
   * Find accessories within a price range
   */
  async findbyPriceRange(model, year = 2018, minPrice, maxPrice) {
    const accessories = await this.searchAccessories(model, year);
    return accessories.filter(item => {
      const price = parseFloat(item.mrp);
      return price >= minPrice && price <= maxPrice;
    }).sort((a, b) => a.mrp - b.mrp);
  }

  /**
   * Search car parts (not accessories)
   */
  async searchParts(model, year = 2018) {
    try {
      // Using fixed modelId=1 as per API specification
      const response = await axios.get(`https://api.hyundaimobisin.com/service/parts/getByModelIdAndYear?modelId=1&year=${year}`);
      
      if (!response.data || !Array.isArray(response.data)) {
        return [];
      }
      
      return response.data.map(item => ({
        id: item.id,
        partName: item.partName || item.name,
        partCode: item.partCode || item.code,
        description: item.description || item.body || 'No description available',
        price: item.price || item.mrp,
        category: item.category || item.type || 'Parts',
        image: item.image ? `https://api.hyundaimobisin.com/service/asset/part/${item.image}` : null
      }));
    } catch (error) {
      console.error('Error fetching parts:', error);
      throw new Error(`Failed to fetch parts: ${error.message}`);
    }
  }

  /**
   * Get all accessory types
   */
  async getAllAccessoryTypes() {
    try {
      const response = await axios.get('https://api.hyundaimobisin.com/service/accessories/getAllTypes');
      return response.data || [];
    } catch (error) {
      console.error('Error fetching accessory types:', error);
      return [];
    }
  }

  /**
   * Get all accessory subtypes
   */
  async getAllAccessorySubtypes() {
    try {
      const response = await axios.get('https://api.hyundaimobisin.com/service/accessories/getAllSubTypes');
      return response.data || [];
    } catch (error) {
      console.error('Error fetching accessory subtypes:', error);
      return [];
    }
  }

  /**
   * Get all parts types
   */
  async getAllPartsTypes() {
    try {
      const response = await axios.get('https://api.hyundaimobisin.com/service/parts/findAllTypes');
      return response.data || [];
    } catch (error) {
      console.error('Error fetching parts types:', error);
      return [];
    }
  }

  /**
   * Validate API key is configured
   */
  isConfigured() {
    return !!process.env.ANTHROPIC_API_KEY;
  }

  /**
   * Get model information
   */
  getModelInfo() {
    return {
      provider: 'Anthropic',
      model: this.model,
      max_tokens: this.maxTokens,
      temperature: this.temperature,
      configured: this.isConfigured()
    };
  }
}

export default HyundaiMobisLLMService; 