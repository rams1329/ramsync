#!/usr/bin/env node

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import axios from 'axios';
import dotenv from 'dotenv';
import HyundaiMobisLLMService from './llm-service.js';

dotenv.config();

// Simple MCP server class for API endpoints
class HyundaiAccessoriesMCPServer {
  constructor() {
    this.MODEL_MAPPINGS = {
      'creta ev': 35,
      'alcazar': 34,
      'creta n line': 31,
      'creta': 29,
      'i20': 27,
      'exter': 26,
      'verna': 23,
      'i10 nios': 25,
      'aura': 24,
      'venue nline': 22,
      'venue': 20,
      'kona': 33,
      'tucson': 30,
      'ioniq': 32,
    };
  }

  async start() {
    // No-op for API usage
  }

  async handleSearchAccessories(args) {
    const { model, year } = args;
    const modelId = this.MODEL_MAPPINGS[model.toLowerCase()];
    
    if (!modelId) {
      return {
        content: [{
          type: 'text',
          text: JSON.stringify([])
        }]
      };
    }

    try {
      const response = await axios.get(`https://api.hyundaimobisin.com/service/accessories/getByModelIdYear?modelId=${modelId}&year=${year}`);
      
      if (!response.data || !Array.isArray(response.data)) {
        return {
          content: [{
            type: 'text',
            text: JSON.stringify([])
          }]
        };
      }
      
      const accessories = response.data.map(item => ({
        id: item.id,
        accessoryName: item.accessoryName,
        accessoryCode: item.accessoryCode,
        body: item.body || 'No description available',
        typeId: item.typeId,
        type: item.type || 'General',
        subTypeId: item.subTypeId,
        subType: item.subType || 'Accessories',
        mrp: item.mrp,
        url: item.url,
        title: item.title,
        image: item.image ? `https://api.hyundaimobisin.com/service/asset/accessory/${item.image}` : null
      }));

      return {
        content: [{
          type: 'text',
          text: JSON.stringify(accessories)
        }]
      };
    } catch (error) {
      console.error('Error fetching accessories:', error);
      return {
        content: [{
          type: 'text',
          text: JSON.stringify([])
        }]
      };
    }
  }

  async handleFindbyType(args) {
    const { model, year, type } = args;
    const accessoriesResult = await this.handleSearchAccessories({ model, year });
    const accessories = JSON.parse(accessoriesResult.content[0].text);
    
    const filtered = accessories.filter(item => 
      item.type && item.type.toLowerCase() === type.toLowerCase()
    );

    return {
      content: [{
        type: 'text',
        text: JSON.stringify(filtered)
      }]
    };
  }

  async handleFindbySubtype(args) {
    const { model, year, subtype } = args;
    const accessoriesResult = await this.handleSearchAccessories({ model, year });
    const accessories = JSON.parse(accessoriesResult.content[0].text);
    const searchTerm = subtype.toLowerCase();
    
    const filtered = accessories.filter(item => {
      // Search in subType field (original behavior)
      const subTypeMatch = item.subType && item.subType.toLowerCase().includes(searchTerm);
      
      // Search in product name
      const nameMatch = item.accessoryName && item.accessoryName.toLowerCase().includes(searchTerm);
      
      // Search in product description/body
      const bodyMatch = item.body && item.body.toLowerCase().includes(searchTerm);
      
      // Search in product title
      const titleMatch = item.title && item.title.toLowerCase().includes(searchTerm);
      
      return subTypeMatch || nameMatch || bodyMatch || titleMatch;
    });

    return {
      content: [{
        type: 'text',
        text: JSON.stringify(filtered)
      }]
    };
  }

  async handleFindbyPriceRange(args) {
    const { model, year, minPrice, maxPrice } = args;
    const accessoriesResult = await this.handleSearchAccessories({ model, year });
    const accessories = JSON.parse(accessoriesResult.content[0].text);
    
    const filtered = accessories.filter(item => {
      const price = parseFloat(item.mrp);
      return price >= minPrice && price <= maxPrice;
    }).sort((a, b) => a.mrp - b.mrp);

    return {
      content: [{
        type: 'text',
        text: JSON.stringify(filtered)
      }]
    };
  }

  async handleSearchParts(args) {
    const { model, year } = args;
    
    try {
      // Using fixed modelId=1 as per API specification
      const response = await axios.get(`https://api.hyundaimobisin.com/service/parts/getByModelIdAndYear?modelId=1&year=${year}`);
      
      if (!response.data || !Array.isArray(response.data)) {
        return {
          content: [{
            type: 'text',
            text: JSON.stringify([])
          }]
        };
      }
      
      const parts = response.data.map(item => ({
        id: item.id,
        partName: item.partName || item.name,
        partCode: item.partCode || item.code,
        description: item.description || item.body || 'No description available',
        price: item.price || item.mrp,
        category: item.category || item.type || 'Parts',
        image: item.image ? `https://api.hyundaimobisin.com/service/asset/part/${item.image}` : null
      }));

      return {
        content: [{
          type: 'text',
          text: JSON.stringify(parts)
        }]
      };
    } catch (error) {
      console.error('Error fetching parts:', error);
      return {
        content: [{
          type: 'text',
          text: JSON.stringify([])
        }]
      };
    }
  }
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Express server setup
const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Serve static files from project root
app.use(express.static(__dirname));

// API endpoint for MCP tool calls
app.post('/api/mcp-call', async (req, res) => {
  try {
    const { tool, args } = req.body;
    
    if (!tool) {
      return res.status(400).json({ error: 'tool name is required' });
    }

    console.log('🔧 Processing MCP tool call via API:', tool, args);
    
    // Create MCP server instance for this request
    const mcpServer = new HyundaiAccessoriesMCPServer();
    await mcpServer.start();
    
    let response;
    switch (tool) {
      case 'searchAccessories':
        response = await mcpServer.handleSearchAccessories(args);
        break;
      case 'findbyType':
        response = await mcpServer.handleFindbyType(args);
        break;
      case 'findbySubtype':
        response = await mcpServer.handleFindbySubtype(args);
        break;
      case 'findbyPriceRange':
        response = await mcpServer.handleFindbyPriceRange(args);
        break;
      case 'searchParts':
        response = await mcpServer.handleSearchParts(args);
        break;
      default:
        return res.status(400).json({ error: `Unknown tool: ${tool}` });
    }
    
    res.json(response);
    
  } catch (error) {
    console.error('MCP API Error:', error);
    res.status(500).json({
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            type: 'error',
            message: 'I apologize, but I\'m experiencing technical difficulties. Please try again in a moment.',
            error: error.message
          })
        }
      ]
    });
  }
});

// API endpoint for LLM queries
app.post('/api/llm-query', async (req, res) => {
  try {
    const { user_input, conversation_history = [] } = req.body;
    
    if (!user_input) {
      return res.status(400).json({ error: 'user_input is required' });
    }

    // Create a temporary LLM service instance for this request
    const llmService = new HyundaiMobisLLMService();
    
    if (!llmService.isConfigured()) {
      return res.status(503).json({ 
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              code: "1",
              message: "LLM service is not configured. Please set ANTHROPIC_API_KEY environment variable."
            })
          }
        ]
      });
    }

    console.log('🤖 Processing LLM query via API:', user_input);
    
    // Generate a simple user ID for spam detection
    const userId = req.ip || 'anonymous';
    
    const response = await llmService.processUserQuery(user_input, conversation_history, userId);
    
    // Return in MCP tool format for consistency
    res.json({
      content: [
        {
          type: 'text',
          text: response.content || JSON.stringify({
            code: "1",
            message: "I can only help with Hyundai Mobis accessories and parts."
          })
        }
      ]
    });
    
  } catch (error) {
    console.error('LLM API Error:', error);
    
    // Check for connectivity issues
    const isConnectivityError = 
      error.message?.includes('ENOTFOUND') ||
      error.message?.includes('Connection error') ||
      error.message?.includes('fetch failed') ||
      error.message?.includes('getaddrinfo');
    
    const errorMessage = isConnectivityError 
      ? '🌐 Unable to connect to AI service. Please check your internet connection and try again.'
      : '🤖 I\'m experiencing technical difficulties with the AI service. Please try again in a moment.';
    
    res.status(500).json({
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            code: "0",
            message: errorMessage
          })
        }
      ]
    });
  }
});

// Additional API endpoints for metadata
app.get('/api/accessory-types', async (req, res) => {
  try {
    const response = await axios.get('https://api.hyundaimobisin.com/service/accessories/getAllTypes');
    res.json(response.data || []);
  } catch (error) {
    console.error('Error fetching accessory types:', error);
    res.status(500).json({ error: 'Failed to fetch accessory types' });
  }
});

app.get('/api/accessory-subtypes', async (req, res) => {
  try {
    const response = await axios.get('https://api.hyundaimobisin.com/service/accessories/getAllSubTypes');
    res.json(response.data || []);
  } catch (error) {
    console.error('Error fetching accessory subtypes:', error);
    res.status(500).json({ error: 'Failed to fetch accessory subtypes' });
  }
});

app.get('/api/parts-types', async (req, res) => {
  try {
    const response = await axios.get('https://api.hyundaimobisin.com/service/parts/findAllTypes');
    res.json(response.data || []);
  } catch (error) {
    console.error('Error fetching parts types:', error);
    res.status(500).json({ error: 'Failed to fetch parts types' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'Hyundai Mobis Accessories Chatbot'
  });
});

// Catch-all route for SPA (must be last and must NOT match /api)
app.get(/^\/(?!api\/).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start Express server
app.listen(port, () => {
  console.log(`🌐 Express server running on http://localhost:${port}`);
  
  // Check LLM configuration
  const llmService = new HyundaiMobisLLMService();
  if (llmService.isConfigured()) {
    console.log('🤖 Claude LLM integration: ENABLED');
    console.log('📊 Model info:', llmService.getModelInfo());
  } else {
    console.log('⚠️  Claude LLM integration: DISABLED (missing ANTHROPIC_API_KEY)');
  }
  
  console.log('');
  console.log('🚗 Hyundai Mobis Accessories Chatbot Ready!');
  console.log('📖 Open your browser to: http://localhost:' + port);
  console.log('');
  console.log('🎯 Features:');
  console.log('   - Rule-based conversation flow');
  console.log('   - AI-powered natural language queries');
  console.log('   - Product carousel with pagination');
  console.log('   - Input validation and spam detection');
  console.log('   - Hyundai brand-compliant UI');
  console.log('');
  console.log('💡 Try these queries:');
  console.log('   - "Show me seat covers for Creta 2018"');
  console.log('   - "What accessories are under ₹5000 for i20?"');
  console.log('   - "I need interior accessories for my Venue"');
  console.log('');
  console.log('🔧 Available MCP Tools:');
  console.log('   - searchAccessories, findbyType, findbySubtype');
  console.log('   - findbyPriceRange, searchParts');
}); 